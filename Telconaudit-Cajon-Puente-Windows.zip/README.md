# Puente de impresora local para el TPV

Este paquete permite que Telconaudit Business envíe el comando de apertura del cajón por la cola de impresión de Windows. El mismo ejecutable local sirve para Chrome y Firefox. Las extensiones solo transportan la solicitud entre la página y el ejecutable.

## Modelo de referencia

La primera validación se prepara para **PRP-310 Thermal Receipt Printer**. El puente no fija un comando de apertura: usa los bytes guardados en la configuración del TPV. La aplicación ya incluye el preajuste PRP-310; hay que confirmarlo con el cajón físico antes de distribuir el paquete.

Windows debe tener instalada la PRP-310 y mostrarla en “Impresoras y escáneres”. El nombre que se configura en el TPV debe coincidir con el nombre de la cola de Windows. El puente envía un trabajo RAW al spooler de impresión. El recibo de un identificador de trabajo indica que Windows lo aceptó; no confirma por sí solo que el cajón se haya abierto.

## Construcción

En Windows con .NET 10 SDK, ejecuta `Build-Package.ps1`. El paquete incluye:

- `artifacts/windows-package`: ejecutable autocontenido y scripts de instalación y desinstalación.
- `artifacts/Telconaudit-Cajon-Chrome.zip`: extensión para Chrome.
- `artifacts/Telconaudit-Cajon-Firefox.zip`: extensión para Firefox.

La extensión de Chrome debe publicarse en Chrome Web Store para obtener un identificador estable. El instalador recibe ese identificador con `-ChromeExtensionId`. Para una prueba de desarrollo, carga la carpeta Chrome como extensión desempaquetada, copia el ID que aparece en `chrome://extensions` y pásalo al instalador. Firefox usa el ID fijo `cajonbridge@telconaudit.es`; la publicación para clientes requiere distribuir una versión firmada por Mozilla.

## Instalación para pruebas

1. Instala o carga la extensión para el navegador que vas a probar.
2. Ejecuta `Install-Bridge.ps1`. Para registrar también Chrome, añade `-ChromeExtensionId <id-de-chrome>`.
3. Cierra y vuelve a abrir el navegador.
4. En TPV Hostelería > Configuración rápida, selecciona **USB con controlador de Windows**, pulsa **Detectar impresoras de Windows** y guarda la cola correspondiente a la PRP-310.
5. Pulsa **Probar cajón Windows**. Después prueba un cobro real de prueba y comprueba el cajón.

El instalador registra el host para el usuario actual en `HKEY_CURRENT_USER`; no requiere elevación ni abre un puerto de red. Para quitarlo, ejecuta `Uninstall-Bridge.ps1` y elimina la extensión del navegador.

## Publicación pendiente

Antes de entregar al cliente, hay que publicar las extensiones firmadas, registrar el ID final de Chrome en el paquete y hacer una prueba física con la PRP-310 y su controlador de Windows. La confirmación del spooler no sustituye esa prueba.
