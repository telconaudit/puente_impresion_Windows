param(
    [string] $ChromeExtensionId = ''
)

$ErrorActionPreference = 'Stop'
$hostName = 'es.telconaudit.cajonbridge'
$firefoxAddonId = 'cajonbridge@telconaudit.es'
$hostSourceDirectory = Join-Path $PSScriptRoot 'host'
$hostSource = Join-Path $hostSourceDirectory 'Telconaudit.CajonBridge.exe'

if (-not (Test-Path -LiteralPath $hostSource -PathType Leaf)) {
    throw 'Falta host\Telconaudit.CajonBridge.exe. Descarga el paquete de Windows completo.'
}
if ($ChromeExtensionId -and $ChromeExtensionId -notmatch '^[a-p]{32}$') {
    throw 'El identificador de Chrome debe tener 32 letras entre a y p.'
}

$installRoot = Join-Path $env:LOCALAPPDATA 'Telconaudit\CajonBridge'
New-Item -ItemType Directory -Path $installRoot -Force | Out-Null
$hostPath = Join-Path $installRoot 'Telconaudit.CajonBridge.exe'
Get-ChildItem -LiteralPath $hostSourceDirectory -Force | Copy-Item -Destination $installRoot -Recurse -Force

function Register-NativeHost([string] $browser, [hashtable] $manifest) {
    $manifestPath = Join-Path $installRoot "$browser-native-host.json"
    $json = $manifest | ConvertTo-Json -Depth 5
    [System.IO.File]::WriteAllText($manifestPath, $json, [System.Text.UTF8Encoding]::new($false))
    $registryPath = "HKCU:\Software\$browser\NativeMessagingHosts\$hostName"
    New-Item -Path $registryPath -Force | Out-Null
    Set-Item -Path $registryPath -Value $manifestPath
}

Register-NativeHost 'Mozilla' @{
    name = $hostName
    description = 'Puente local de impresoras para Telconaudit Business'
    path = $hostPath
    type = 'stdio'
    allowed_extensions = @($firefoxAddonId)
}

if ($ChromeExtensionId) {
    Register-NativeHost 'Google\Chrome' @{
        name = $hostName
        description = 'Puente local de impresoras para Telconaudit Business'
        path = $hostPath
        type = 'stdio'
        allowed_origins = @("chrome-extension://$ChromeExtensionId/")
    }
}

Write-Host 'Puente local instalado para Firefox.'
if ($ChromeExtensionId) {
    Write-Host 'Puente local instalado para Chrome.'
} else {
    Write-Host 'Para habilitar Chrome, vuelve a ejecutar el instalador con -ChromeExtensionId y el ID de la extensión publicada.'
}
Write-Host 'Cierra y vuelve a abrir el navegador después de instalar o actualizar el puente.'
