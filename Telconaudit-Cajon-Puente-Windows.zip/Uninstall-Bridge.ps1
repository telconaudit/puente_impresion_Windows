$ErrorActionPreference = 'Stop'
$hostName = 'es.telconaudit.cajonbridge'
@(
    "HKCU:\Software\Mozilla\NativeMessagingHosts\$hostName",
    "HKCU:\Software\Google\Chrome\NativeMessagingHosts\$hostName"
) | ForEach-Object {
    if (Test-Path -LiteralPath $_) { Remove-Item -LiteralPath $_ -Force }
}

$installRoot = Join-Path $env:LOCALAPPDATA 'Telconaudit\CajonBridge'
if (Test-Path -LiteralPath $installRoot) { Remove-Item -LiteralPath $installRoot -Recurse -Force }
Write-Host 'Puente local desinstalado. Elimina también la extensión de Chrome o Firefox desde su página de extensiones.'
